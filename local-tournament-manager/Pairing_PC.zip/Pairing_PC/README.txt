This folder contains the Tournament Manager.

Usage:
1. If this is the FIRST time, please download and install Node.js from https://nodejs.org/ (LTS version)
2. Double click 'start.bat' to run the program.

The browser should open automatically.
If not, open http://localhost:3000 in your browser.
